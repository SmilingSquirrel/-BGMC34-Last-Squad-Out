Last Squad Out

Made by SmilingSquirrel
for BGMC34 (1/31/21 - 2/7/21)

Themes: You can't save them all  and  You're not the only hero
Mechanic: Any mechanic

In Last Squad Out you assume the role of Maethan and have to escape a lab overrun by mutants. (Because, things are always going wrong in labs, duh.)


Controls: (The game requires a Gamepad to play.)

Left joystick- Moves your selected character.
Left trigger - Selects next member of your squad.
"B" button   - Removes selected unit from squad, pressing "B" again while selected will bring them back into the squad.

(Shooting is done by the characters automaticly.)



Known Issues:

If you run your chacter into a pile of enemies, the screen may turn green/grey and nothing seems to respond. "ESC" is the only way out, I'm afraid. It seems to be a physics issue...
